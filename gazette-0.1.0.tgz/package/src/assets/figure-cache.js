// Raster fallback PNGs for interactive figures. `gazette snapshot` renders each
// component in headless Chrome and writes the screenshot here, into the on-disk
// cache rather than the source tree:
//
//   <root>/.gazette-cache/figures/<slug>.png
//
// Like the remote-dataset cache, this lives OUTSIDE `dist` and outside the
// author's `figures/` tree, so the generated binaries are not committed and
// survive `rm -rf dist`. The static and pdf targets copy the cached PNGs into
// their output's figures/ dir so the fallback `<img src="figures/<slug>.png">`
// resolves; the browser-facing path is unchanged.
import fs from "node:fs";
import path from "node:path";

export function figuresCacheDir(config) {
  return path.join(config.rootDir, ".gazette-cache", "figures");
}

export function fallbackCacheFile(config, slug) {
  return path.join(figuresCacheDir(config), `${slug}.png`);
}

// Copy each island's cached fallback PNG into <outDir>/figures/<slug>.png. A
// missing cache file is skipped (the static page then 404s that fallback until
// `gazette snapshot` is run); callers that require the fallbacks — the pdf
// target — assert their presence separately. Returns the slugs actually staged.
export async function stageFigureFallbacks(config, ir, outDir) {
  const islands = ir.data.islands || [];
  const staged = [];
  let destDir = null;
  for (const island of islands) {
    const src = fallbackCacheFile(config, island.slug);
    if (!fs.existsSync(src)) continue;
    if (!destDir) {
      destDir = path.join(outDir, "figures");
      await fs.promises.mkdir(destDir, { recursive: true });
    }
    await fs.promises.copyFile(src, path.join(destDir, `${island.slug}.png`));
    staged.push(island.slug);
  }
  return staged;
}
