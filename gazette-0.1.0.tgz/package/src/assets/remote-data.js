// Remote figure datasets. A figure's `data:` value may be an https URL instead
// of a local file; the browser must still fetch a *relative* path (so the built
// page is portable), so the URL's contents are fetched at build/dev time, cached
// on disk, and copied into the output's figures/data/ tree under a derived name.
//
// The cache lives OUTSIDE the output directory — at <root>/.gazette-cache/remote/
// — so it survives `rm -rf dist`, a clean CI build, and a different `--out`, and
// is shared across `dev`, `build`, and `snapshot`. "Already fetched" simply means
// "present in the cache": a URL is fetched at most once, then reused forever
// (delete the cache dir to force a refetch).
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const FETCH_TIMEOUT_MS = 30_000;

// Derive a stable local filename from a remote URL: drop the scheme and domain,
// strip the .json extension, flatten the path ("/" and any other unsafe chars
// become "_"), then append a short hash of the full URL (query included) so two
// URLs that flatten to the same stem never collide. The .json extension is
// restored at the end.
//
//   https://raw.githubusercontent.com/org/repo/main/data/demo.json
//     -> org_repo_main_data_demo_1a2b3c.json
export function remoteCacheName(url) {
  const u = new URL(url);
  let base = u.pathname.replace(/^\/+/, "");
  base = base.replace(/\.json$/i, "");
  base = base.replace(/\//g, "_").replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^_+|_+$/g, "");
  const hash = crypto.createHash("sha256").update(url).digest("hex").slice(0, 6);
  return `${base || "data"}_${hash}.json`;
}

function cacheDirFor(config) {
  return path.join(config.rootDir, ".gazette-cache", "remote");
}

// The unique remote datasets referenced by the document's islands, each with the
// local filename the parser assigned (figures/data/<name>) and its cache path.
export function remoteDatasets(config, ir) {
  const dir = cacheDirFor(config);
  const seen = new Map();
  for (const island of ir.data.islands || []) {
    for (const d of Object.values(island.data || {})) {
      if (!d.remote || seen.has(d.remote)) continue;
      const name = path.basename(d.path);
      seen.set(d.remote, { url: d.remote, name, cacheFile: path.join(dir, name) });
    }
  }
  return { dir, items: [...seen.values()] };
}

// Fetch one remote dataset to text. The URL comes from the document's own figure
// config (author-controlled), but is still constrained: https only — including
// after any redirects — with a timeout so a build cannot hang, and validated as
// JSON so a bad response is caught at build time rather than shipped.
async function fetchToText(url) {
  if (new URL(url).protocol !== "https:") {
    throw new Error(`remote dataset must use https: ${url}`);
  }
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), FETCH_TIMEOUT_MS);
  let res;
  try {
    res = await fetch(url, {
      redirect: "follow",
      signal: ac.signal,
      headers: { Accept: "application/json" },
    });
  } catch (err) {
    throw new Error(`failed to fetch remote dataset ${url}: ${err.message}`);
  } finally {
    clearTimeout(timer);
  }
  if (!res.ok) throw new Error(`failed to fetch remote dataset ${url}: HTTP ${res.status}`);
  if (!/^https:/i.test(res.url || url)) {
    throw new Error(`remote dataset ${url} redirected to a non-https URL: ${res.url}`);
  }
  const text = await res.text();
  try {
    JSON.parse(text);
  } catch (err) {
    throw new Error(`remote dataset ${url} is not valid JSON: ${err.message}`);
  }
  return text;
}

// Ensure every remote dataset is cached (fetch once, skip if already present),
// then copy the cached files into <outDir>/figures/data/ so the page serves them
// from a relative path exactly like a local dataset. Returns the staged items.
export async function stageRemoteData(config, ir, outDir, { log } = {}) {
  const { dir, items } = remoteDatasets(config, ir);
  if (!items.length) return [];
  await fs.promises.mkdir(dir, { recursive: true });
  const destDir = path.join(outDir, "figures", "data");
  await fs.promises.mkdir(destDir, { recursive: true });
  for (const it of items) {
    if (!fs.existsSync(it.cacheFile)) {
      const text = await fetchToText(it.url);
      await fs.promises.writeFile(it.cacheFile, text);
      if (log) log(it);
    }
    await fs.promises.copyFile(it.cacheFile, path.join(destDir, it.name));
  }
  return items;
}
