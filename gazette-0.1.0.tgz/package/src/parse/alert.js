// GitHub-style alert/callout blockquotes. A blockquote whose first line is a
// bare `[!TYPE]` marker:
//
//   > [!NOTE]
//   > Highlights information users should take into account.
//
// is lowered to a <div class="gazette-note gazette-note--note"> (NOT a
// <blockquote>), with the `[!TYPE]` marker stripped from the rendered content.
// The marker only selects the class; it never appears in the output. The five
// GitHub alert types are recognized; each maps to a `gazette-note--<type>`
// modifier class so the theme can style them individually, over the shared
// `gazette-note` base. An ordinary blockquote (no marker) is left untouched.
import { visit } from "unist-util-visit";

const TYPES = new Set(["note", "tip", "important", "warning", "caution"]);
// Marker must be alone on the first line (optional trailing spaces), matching
// GitHub: `> [!NOTE] text` on one line is a plain quote, not an alert.
const MARKER_RE = /^\[!([A-Za-z]+)\][ \t]*(?:\r?\n|$)/;

export function remarkAlerts() {
  return (tree) => {
    visit(tree, "blockquote", (node) => {
      const firstPara = node.children && node.children[0];
      if (!firstPara || firstPara.type !== "paragraph") return;
      const firstText = firstPara.children && firstPara.children[0];
      if (!firstText || firstText.type !== "text") return;

      const m = MARKER_RE.exec(firstText.value);
      if (!m) return;
      const type = m[1].toLowerCase();
      if (!TYPES.has(type)) return;

      // Strip the marker line from the content.
      firstText.value = firstText.value.slice(m[0].length);
      // If that left the marker's paragraph empty (content began in a later,
      // blank-line-separated paragraph), drop the now-empty paragraph.
      if (firstText.value === "" && firstPara.children.length === 1) {
        node.children.shift();
      }

      // Render as a <div>, not a <blockquote>, with the note classes.
      node.data = node.data || {};
      node.data.hName = "div";
      node.data.hProperties = {
        ...(node.data.hProperties || {}),
        className: ["gazette-note", `gazette-note--${type}`],
      };
    });
  };
}
