// hast transform (runs after remark-rehype + rehype-katex) that resolves the
// bracketed reference syntax in the prose text, and unifies citations with
// GFM footnotes into a single numbered list:
//
//   [@fig:slug]            -> <a href="#fig-slug">Figure N</a>   (cross-reference)
//   [@key]  [@k1; @k2]     -> <sup><a href="#ref-k1">N</a>,…</sup>  (citation)
//   [^label] (+ a bottom-  -> <sup><a href="#ref-fn-label">N</a></sup> (footnote)
//     of-file definition
//     `[^label]: text`)
//
// Citation and footnote markers render as a bracketless superscript number (not
// "[N]"); multiple citations in one group share a single <sup>.
//
// Citations and footnotes share ONE numbering counter, assigned by first
// appearance in document order, so the two interleave. The combined list is
// appended as a <section class="gazette-references"> at the end of the body; its
// heading is "References", "Footnotes", or "References & Footnotes" depending on
// what it contains.
//
// GFM (remark-gfm) already tokenizes `[^label]` references and `[^label]:`
// definitions: by the time this transform runs, a *defined* footnote reference
// is a <sup><a data-footnote-ref>N</a></sup> and the definitions live in a
// trailing <section data-footnotes>. We renumber those references into the
// shared counter, lift their content into the combined list, and drop GFM's own
// footnotes section. An *undefined* footnote reference is left verbatim by GFM
// as literal `[^label]` text — we warn and leave it. The full set of defined
// labels is collected from the mdast by remarkCollectFootnoteDefs (below) so we
// can also warn about a definition that is never referenced.

import { formatReference } from "../bibtex.js";

const BRACKET_RE = /\[([^\]\[]+)\]/g;
const SKIP_TAGS = new Set(["code", "pre", "a", "script", "style"]);

// GFM's DOM id prefixes for footnote references and definitions.
const FNDEF_ID_PREFIX = "user-content-fn-";
const FNREF_ID_PREFIX = "user-content-fnref-";

function el(tagName, properties, children) {
  return { type: "element", tagName, properties: properties || {}, children: children || [] };
}
function txt(value) {
  return { type: "text", value };
}

function isSkipped(node) {
  if (node.type !== "element") return false;
  if (SKIP_TAGS.has(node.tagName)) return true;
  const cls = node.properties && node.properties.className;
  return Array.isArray(cls) && cls.some((c) => String(c).startsWith("katex") || String(c).startsWith("math"));
}

// mdast plugin: record every footnote definition label (including ones never
// referenced, which remark-rehype would otherwise silently drop) so the hast
// transform can warn about orphans. Runs before remark-rehype.
export function remarkCollectFootnoteDefs() {
  return (tree, file) => {
    const defined = (file.data.footnoteDefined ||= new Set());
    // identifier (normalized, used for matching) -> label (as authored, for
    // readable warnings).
    const labels = (file.data.footnoteLabels ||= new Map());
    (function walk(n) {
      if (n.type === "footnoteDefinition" && n.identifier) {
        const ident = String(n.identifier);
        defined.add(ident);
        if (!labels.has(ident)) labels.set(ident, String(n.label ?? ident));
      }
      (n.children || []).forEach(walk);
    })(tree);
  };
}

// A <sup> wrapping a GFM footnote reference? Return the definition label (stable
// across repeated references to the same note), else null. The label is taken
// from the link's href (`#user-content-fn-LABEL`, which points at the
// definition) in preference to its id (`user-content-fnref-LABEL`, which gains a
// `-2`, `-3`… suffix on repeated references).
function footnoteRefLabel(node) {
  if (node.type !== "element" || node.tagName !== "sup") return null;
  const a = (node.children || []).find((c) => c.type === "element" && c.tagName === "a");
  if (!a || !a.properties || !a.properties.dataFootnoteRef) return null;
  const href = String(a.properties.href || "");
  if (href.startsWith("#" + FNDEF_ID_PREFIX)) return href.slice(1 + FNDEF_ID_PREFIX.length);
  const id = String(a.properties.id || "");
  if (id.startsWith(FNREF_ID_PREFIX)) return id.slice(FNREF_ID_PREFIX.length).replace(/-\d+$/, "");
  return null;
}

// GFM appends a "↩" back-reference link to each footnote; drop it (and trailing
// whitespace before it) when we lift the content into the combined list.
function isBackref(n) {
  if (n.type !== "element" || n.tagName !== "a" || !n.properties) return false;
  if (n.properties.dataFootnoteBackref != null) return true;
  const cls = n.properties.className;
  return Array.isArray(cls) && cls.some((c) => String(c).includes("footnote-backref"));
}

function stripBackref(nodes) {
  const out = nodes.filter((n) => !isBackref(n));
  while (out.length) {
    const last = out[out.length - 1];
    if (last.type === "text" && !last.value.trim()) out.pop();
    else break;
  }
  return out;
}

// Extract a footnote definition <li>'s content as inline hast nodes. A single
// wrapping <p> is unwrapped so a one-line note renders like a reference line;
// multi-block notes keep their structure (back-ref stripped from the last <p>).
function noteBody(li) {
  const blocks = (li.children || []).filter(
    (n) => n.type === "element" || (n.type === "text" && n.value.trim())
  );
  if (blocks.length === 1 && blocks[0].type === "element" && blocks[0].tagName === "p") {
    return stripBackref(blocks[0].children || []);
  }
  const last = blocks[blocks.length - 1];
  if (last && last.type === "element" && last.tagName === "p") {
    last.children = stripBackref(last.children || []);
  }
  return blocks;
}

export function rehypeResolveRefs(options = {}) {
  const { bib = {}, warnings = [] } = options;

  return (tree, file) => {
    const figuresBySlug = file.data.figuresBySlug || new Map();
    const definedNotes = file.data.footnoteDefined || new Set();
    const noteLabels = file.data.footnoteLabels || new Map();

    // One ordered counter shared by citations and footnotes. `refsOrder` holds
    // { kind: "cite"|"note", id } in numbering order; `refNumbers` maps a
    // namespaced token to its number.
    const refsOrder = (file.data.refsOrder ||= []);
    const refNumbers = (file.data.refNumbers ||= new Map());
    const warnedMissing = new Set();

    function assign(kind, id) {
      const token = `${kind}:${id}`;
      let n = refNumbers.get(token);
      if (n == null) {
        n = refsOrder.length + 1;
        refNumbers.set(token, n);
        refsOrder.push({ kind, id });
      }
      return n;
    }

    // Index GFM's footnote definitions by label (keeping the live <li> nodes so
    // citations inside them are resolved by the walk below), then detach the
    // section so it is not rendered twice.
    const fnSectionIndex = tree.children.findIndex(
      (n) => n.type === "element" && n.tagName === "section" && n.properties && n.properties.dataFootnotes
    );
    const noteItems = new Map(); // label -> <li>
    if (fnSectionIndex >= 0) {
      const section = tree.children[fnSectionIndex];
      const ol = (section.children || []).find((n) => n.type === "element" && n.tagName === "ol");
      for (const li of (ol && ol.children) || []) {
        if (li.type !== "element" || li.tagName !== "li") continue;
        const id = String((li.properties && li.properties.id) || "");
        if (id.startsWith(FNDEF_ID_PREFIX)) noteItems.set(id.slice(FNDEF_ID_PREFIX.length), li);
      }
    }

    // Classify a bracket's inner content; return replacement hast nodes, or null
    // to leave the literal `[...]` untouched.
    function resolveBracket(inner) {
      const trimmed = inner.trim();

      // Undefined footnote reference: GFM leaves these literal. Warn, keep text.
      if (/^\^[^\s;]+$/.test(trimmed)) {
        const label = trimmed.slice(1);
        if (!definedNotes.has(label) && !warnedMissing.has(label)) {
          warnedMissing.add(label);
          warnings.push(`footnote reference without definition: [^${label}]`);
        }
        return null;
      }

      const tokens = inner.split(";").map((t) => t.trim());
      if (tokens.length === 0) return null;

      // Cross-reference group: every token is @fig:slug
      if (tokens.every((t) => /^@fig:[^\s;]+$/.test(t))) {
        const out = [];
        tokens.forEach((t, i) => {
          const slug = t.slice(5); // drop "@fig:"
          const fig = figuresBySlug.get(slug);
          if (!fig) {
            warnings.push(`cross-reference to unknown figure: [@fig:${slug}]`);
            return null;
          }
          if (i > 0) out.push(txt(", "));
          out.push(el("a", { href: `#${fig.figId}` }, [txt(`Figure ${fig.number}`)]));
        });
        return out.length ? out : null;
      }

      // Citation group: every token is a bare @key (no colon)
      if (tokens.every((t) => /^@[^\s:;]+$/.test(t))) {
        // The document cites at least one source — recorded whether or not the
        // key resolves, so callers can tell a document that needs a bibliography
        // from one that doesn't (e.g. to gate the "bibliography not found" warning).
        file.data.hasCitations = true;
        const keys = tokens.map((t) => t.slice(1));
        const missing = keys.filter((k) => !bib[k]);
        if (missing.length) {
          warnings.push(`citation key(s) not found in bibliography: ${missing.join(", ")}`);
          return null;
        }
        const links = [];
        keys.forEach((k, i) => {
          if (i > 0) links.push(txt(","));
          links.push(el("a", { href: `#ref-${k}` }, [txt(String(assign("cite", k)))]));
        });
        return [el("sup", { className: ["gazette-ref-mark"] }, links)];
      }

      return null;
    }

    function processText(value) {
      const nodes = [];
      let last = 0;
      let m;
      BRACKET_RE.lastIndex = 0;
      while ((m = BRACKET_RE.exec(value))) {
        const replacement = resolveBracket(m[1]);
        if (!replacement) continue;
        if (m.index > last) nodes.push(txt(value.slice(last, m.index)));
        nodes.push(...replacement);
        last = m.index + m[0].length;
      }
      if (nodes.length === 0) return null; // unchanged
      if (last < value.length) nodes.push(txt(value.slice(last)));
      return nodes;
    }

    // Render a footnote marker identically to a citation marker (a bracketless
    // superscript number linking into the combined list), assigning its number
    // from the shared counter.
    function noteMarker(label) {
      const n = assign("note", label);
      return [
        el("sup", { className: ["gazette-ref-mark"] }, [
          el("a", { href: `#ref-fn-${label}` }, [txt(String(n))]),
        ]),
      ];
    }

    function walk(node, skip) {
      if (!node.children) return;
      const next = [];
      for (const child of node.children) {
        if (child.type === "text" && !skip) {
          const replaced = processText(child.value);
          if (replaced) next.push(...replaced);
          else next.push(child);
          continue;
        }
        const label = skip ? null : footnoteRefLabel(child);
        if (label) {
          next.push(...noteMarker(label));
        } else {
          walk(child, skip || isSkipped(child));
          next.push(child);
        }
      }
      node.children = next;
    }

    walk(tree, false);

    // Drop GFM's footnotes section now that references are renumbered and the
    // content has been resolved in place.
    if (fnSectionIndex >= 0) {
      const idx = tree.children.findIndex(
        (n) => n.type === "element" && n.tagName === "section" && n.properties && n.properties.dataFootnotes
      );
      if (idx >= 0) tree.children.splice(idx, 1);
    }

    // Warn about definitions that were never referenced (GFM already dropped
    // them from the output; we only surface the warning).
    const referenced = new Set(refsOrder.filter((e) => e.kind === "note").map((e) => e.id));
    for (const label of definedNotes) {
      if (!referenced.has(label)) {
        warnings.push(`footnote defined but never referenced: [^${noteLabels.get(label) || label}]`);
      }
    }

    wrapAcknowledgments(tree);
    appendRefsAndNotes(tree, refsOrder, bib, noteItems);
  };
}

// Wrap the "Acknowledgments" h2 and its following siblings (up to the next h2)
// in <section class="gazette-acknowledgments">, reproducing the studied output.
function wrapAcknowledgments(tree) {
  const kids = tree.children;
  const start = kids.findIndex(
    (n) => n.type === "element" && n.tagName === "h2" && n.properties && n.properties.id === "acknowledgments"
  );
  if (start < 0) return;
  let end = start + 1;
  while (end < kids.length && !(kids[end].type === "element" && kids[end].tagName === "h2")) end++;
  const section = el("section", { className: ["gazette-acknowledgments"] }, kids.slice(start, end));
  tree.children = [...kids.slice(0, start), section, ...kids.slice(end)];
}

// Append the combined numbered list of citations and footnotes, in the shared
// numbering order. The heading reflects what the list actually contains.
function appendRefsAndNotes(tree, refsOrder, bib, noteItems) {
  if (!refsOrder.length) return;

  const items = refsOrder.map(({ kind, id }) => {
    if (kind === "cite") {
      return el("li", { id: `ref-${id}`, className: ["gazette-reference"] }, [txt(formatReference(bib[id]))]);
    }
    const li = noteItems.get(id);
    const body = li ? noteBody(li) : [txt("")];
    return el("li", { id: `ref-fn-${id}`, className: ["gazette-reference", "gazette-footnote"] }, body);
  });

  const hasCite = refsOrder.some((e) => e.kind === "cite");
  const hasNote = refsOrder.some((e) => e.kind === "note");
  const title = hasCite && hasNote ? "References & Footnotes" : hasNote ? "Footnotes" : "References";

  const section = el("section", { className: ["gazette-references"], "aria-label": title }, [
    el("h2", {}, [txt(title)]),
    el("ol", { className: ["gazette-reference-list"] }, items),
  ]);
  tree.children.push(section);
}
