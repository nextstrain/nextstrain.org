// `gazette build <input> --target <static|pdf|all>`
import fs from "node:fs";
import path from "node:path";
import { loadConfig, VENDOR } from "../config.js";
import { parseBibtex } from "../bibtex.js";
import { parseDocument } from "../parse/pipeline.js";
import { renderStaticArticle } from "../render/target-static.js";
import { buildPdf } from "../render/target-pdf.js";
import { generateSnapshots } from "../render/snapshots.js";
import { copyStaticAssets } from "../assets/copy.js";
import { stageRemoteData } from "../assets/remote-data.js";
import { stageFigureFallbacks } from "../assets/figure-cache.js";

function validate(data, warnings) {
  const figIds = new Set((data.islands || []).map((i) => i.figId));
  for (const t of data.triggers || []) {
    if (!figIds.has(t.target)) {
      warnings.push(`trigger target has no matching figure: ${t.target}`);
    }
  }
}

// Build the shared IR once, reused by every target.
export async function buildIR(config, warnings) {
  const markdown = fs.readFileSync(config.entry, "utf8");
  const bibExists = fs.existsSync(config.bibPath);
  const bib = bibExists ? parseBibtex(fs.readFileSync(config.bibPath, "utf8")) : {};
  const { html, data } = await parseDocument({ markdown, bib, warnings });
  // Only warn about a missing bibliography when the document actually cites: a
  // document with no [@key] citations needs no bib file.
  if (!bibExists && data.hasCitations) {
    warnings.push(`bibliography not found: ${config.bibPath} (citations will be left literal)`);
  }
  validate(data, warnings);
  return { html, data };
}

// The built PDF lives at <outBase>/<config.pdfName> (written by the `pdf`
// target); its name derives from the Markdown entry file (foo.md -> foo.pdf).
function pdfSource(config) {
  return path.join(config.outBase, config.pdfName);
}

// When frontmatter sets `pdf-download: true`, the `static` build surfaces a
// Download PDF link and ships the file alongside the page. The PDF must already
// exist (build it with `--target pdf`/`all`); we assert rather than regenerate,
// and don't check whether it is up to date. Returns { link, copy }: `link` adds
// the Download PDF anchor, `copy` ships the file beside the page.
//
// In `dev` the assertion is relaxed — the link is still rendered but is allowed
// to 404 until a `pdf` build produces the file, so the live-reload loop isn't
// blocked by a missing artifact.
function pdfDownloadPlan(config, ir) {
  if (!ir.data.frontmatter || ir.data.frontmatter["pdf-download"] !== true) {
    return { link: false, copy: false };
  }
  const src = pdfSource(config);
  if (fs.existsSync(src)) return { link: true, copy: true };
  if (config.dev) return { link: true, copy: false };
  throw new Error(
    `pdf-download: true, but the PDF does not exist at ${path.relative(process.cwd(), src)}.\n` +
      `  Build it first:  gazette build ${path.relative(process.cwd(), config.entry)} --target pdf`
  );
}

async function buildStatic(config, ir) {
  const outDir = path.join(config.outBase, "static");
  const pdf = pdfDownloadPlan(config, ir);
  const article = renderStaticArticle({
    html: ir.html,
    data: ir.data,
    hideFallback: config.hideFallback,
    pdfHref: pdf.link ? config.pdfName : undefined,
  });
  const template = fs.readFileSync(VENDOR.template, "utf8");
  const title = (ir.data.frontmatter && ir.data.frontmatter.title) || "Untitled";
  const page = template.replace("{{title}}", escapeTitle(title)).replace("{{article}}", article);

  await fs.promises.mkdir(outDir, { recursive: true });
  await fs.promises.writeFile(path.join(outDir, "index.html"), page);
  await copyStaticAssets({ outDir, figuresDir: config.figuresDir, themeDir: config.themeDir });
  await stageRemoteData(config, ir, outDir, {
    log: (it) => console.log(`gazette: fetched remote dataset ${it.url} -> figures/data/${it.name}`),
  });
  // Copy cached raster fallbacks into the output (figures/<slug>.png). Missing
  // ones are left to 404 — the static page hides the fallback once the island
  // hydrates, so an un-snapshotted figure still works live.
  await stageFigureFallbacks(config, ir, outDir);
  if (pdf.copy) await fs.promises.copyFile(pdfSource(config), path.join(outDir, config.pdfName));
  return outDir;
}

function escapeTitle(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export async function buildCommand(input, cli) {
  const config = loadConfig(input, cli);
  const warnings = [];
  const ir = await buildIR(config, warnings);

  // `--snapshot` regenerates the raster fallback PNGs (in the source figures/
  // tree) before building, so the no-JS/pdf fallbacks are up to date.
  if (cli.snapshot && (ir.data.islands || []).length) {
    const { written } = await generateSnapshots(config, ir);
    console.log(`gazette: snapshotted ${written.length} figure(s) before build`);
  }

  // `all` builds every implemented target. `pdf` goes first so that, when a
  // document opts into `pdf-download`, the file exists for the static build to
  // assert and ship.
  const targets = config.target === "all" ? ["pdf", "static"] : [config.target];
  const built = [];
  for (const target of targets) {
    if (target === "static") built.push(["static", `${await buildStatic(config, ir)}/index.html`]);
    else if (target === "pdf") built.push(["pdf", await buildPdf(config, ir)]);
    else throw new Error(`Unknown target: ${target}`);
  }

  // Report.
  const nFigs = (ir.data.islands || []).length;
  const order = ir.data.refsOrder || [];
  const nRefs = order.filter((e) => e.kind === "cite").length;
  const nNotes = order.filter((e) => e.kind === "note").length;
  const nTrig = (ir.data.triggers || []).length;
  const noteStr = nNotes ? `, ${nNotes} footnote(s)` : "";
  console.log(`gazette: built ${path.basename(config.entry)} — ${nFigs} figure(s), ${nTrig} trigger(s), ${nRefs} reference(s)${noteStr}`);
  for (const [target, outPath] of built) {
    console.log(`  ${target} -> ${path.relative(process.cwd(), outPath)}`);
  }
  if (warnings.length) {
    console.log(`gazette: ${warnings.length} warning(s):`);
    for (const w of warnings) console.log(`  ! ${w}`);
  }
  return { config, ir, built };
}
