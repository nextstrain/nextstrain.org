// Shared dataset loader for figure islands. One document can render many figures
// that reference the same JSON file; a naive per-island `fetch` would pull — and
// re-parse — the same file once per figure. This module memoizes by URL so each
// distinct dataset is fetched and parsed exactly once, however many islands use
// it: the browser's module map guarantees every island's inline hydration script
// imports this one module instance, so they all share the `cache` below (and a
// request already in flight is shared too, since the promise is cached).
//
// Each island still receives its OWN copy of the data, so a component that
// mutates what it was handed cannot corrupt the shared cache or another figure's
// data. The data is always JSON, so a JSON round-trip is a sufficient deep clone
// — and, for plain JSON-shaped values, cheaper than structuredClone.
const cache = new Map();

export function loadJSON(url) {
  let parsed = cache.get(url);
  if (!parsed) {
    parsed = fetch(url).then((r) => {
      if (!r.ok) throw new Error(`gazette: failed to fetch ${url} (${r.status})`);
      return r.json();
    });
    cache.set(url, parsed);
  }
  // Clone per call: the cached promise resolves to the single shared parsed
  // value, and each caller gets an independent copy of it.
  return parsed.then((value) => JSON.parse(JSON.stringify(value)));
}
